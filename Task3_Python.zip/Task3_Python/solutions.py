# Q1. Find the Frequency of Each Word in a Sentence
def q1_word_frequency(sentence):
    words = sentence.split()
    frequency = {}
    for word in words:
        if word in frequency:
            frequency[word] += 1
        else:
            frequency[word] = 1
    return frequency


# Q2. Find the Frequency of Each Character in a Word
def q2_character_frequency(word):
    frequency = {}
    for character in word:
        if character in frequency:
            frequency[character] += 1
        else:
            frequency[character] = 1
    return frequency


# Q3. Find the First Non-Repeating Character in a Word
def q3_first_non_repeating(word):
    for character in word:
        if word.count(character) == 1:
            return character
    return None


# Q4. Check Whether Two Strings Are Anagrams
def q4_are_anagrams(s1, s2):
    if len(s1) != len(s2):
        return False
    for character in s1:
        if s1.count(character) != s2.count(character):
            return False
    return True


# Q5. Find the First Repeating Character in a String
def q5_first_repeating(word):
    seen = []
    for character in word:
        if character in seen:
            return character
        seen.append(character)
    return None


# Q6. Move All Zeros to the End of a List
def q6_move_zeros(nums):
    result = []
    zero_count = 0
    for number in nums:
        if number == 0:
            zero_count += 1
        else:
            result.append(number)
    for _ in range(zero_count):
        result.append(0)
    return result


# Q7. Find the Second Highest Distinct Number in a List
def q7_second_highest(nums):
    unique_numbers = []
    for number in nums:
        if number not in unique_numbers:
            unique_numbers.append(number)
    if len(unique_numbers) < 2:
        return None
    highest = unique_numbers[0]
    second_highest = None
    for number in unique_numbers:
        if number > highest:
            second_highest = highest
            highest = number
        elif number < highest:
            if second_highest is None or number > second_highest:
                second_highest = number
    return second_highest


# Q8. Remove Duplicates Without Changing the Original Order
def q8_remove_duplicates(nums):
    result = []
    for number in nums:
        if number not in result:
            result.append(number)
    return result


# Q9. Find the Missing Number from 1 to N
def q9_missing_number(nums, n):
    for number in range(1, n + 1):
        if number not in nums:
            return number
    return None


# Q10. Find Two Numbers Whose Sum Equals a Target
# The first pair is selected by the earliest second element encountered.
def q10_two_sum(nums, target):
    for right_index in range(len(nums)):
        for left_index in range(right_index):
            if nums[left_index] + nums[right_index] == target:
                return [nums[left_index], nums[right_index]]
    return []


# Q11. Find the Number Closest to Zero
# If equally close negative and positive values exist, choose the positive value.
def q11_closest_to_zero(nums):
    closest = nums[0]
    for number in nums[1:]:
        if abs(number) < abs(closest):
            closest = number
        elif abs(number) == abs(closest) and number > closest:
            closest = number
    return closest


# Q12. Find Common Elements Between Two Lists
def q12_common_elements(list1, list2):
    result = []
    for number in list1:
        if number in list2 and number not in result:
            result.append(number)
    return result


# Q13. Rotate a List to the Right by K Positions
def q13_rotate_right(nums, k):
    if len(nums) == 0:
        return []
    k = k % len(nums)
    result = []
    for index in range(len(nums) - k, len(nums)):
        result.append(nums[index])
    for index in range(0, len(nums) - k):
        result.append(nums[index])
    return result


# Q14. Find the Maximum Sum of Two Consecutive Elements
def q14_max_consecutive_sum(nums):
    maximum_sum = nums[0] + nums[1]
    for index in range(1, len(nums) - 1):
        current_sum = nums[index] + nums[index + 1]
        if current_sum > maximum_sum:
            maximum_sum = current_sum
    return maximum_sum


# Q15. Find All Pairs of Numbers Whose Sum Equals a Target
def q15_all_pairs(nums, target):
    pairs = []
    for first_index in range(len(nums)):
        for second_index in range(first_index + 1, len(nums)):
            first = nums[first_index]
            second = nums[second_index]
            if first + second == target:
                if first <= second:
                    pair = [first, second]
                else:
                    pair = [second, first]
                if pair not in pairs:
                    pairs.append(pair)
    pairs.sort()
    return pairs
