from solutions import (
    q1_word_frequency,
    q2_character_frequency,
    q3_first_non_repeating,
    q4_are_anagrams,
    q5_first_repeating,
    q6_move_zeros,
    q7_second_highest,
    q8_remove_duplicates,
    q9_missing_number,
    q10_two_sum,
    q11_closest_to_zero,
    q12_common_elements,
    q13_rotate_right,
    q14_max_consecutive_sum,
    q15_all_pairs,
)

def main():
    # Q1: 
    print("Q1 example:",q1_word_frequency("python is easy and python is powerful"))
    print("Q1 test:",q1_word_frequency("red blue red"))

    # Q2
    print("Q2 example:",q2_character_frequency("banana"))
    print("Q2 test:",q2_character_frequency("hello"))

    # Q3
    print("Q3 example:",q3_first_non_repeating("swiss"))
    print("Q3 test:",q3_first_non_repeating("aabb"))

    # Q4
    print("Q4 example:",q4_are_anagrams("listen", "silent"))
    print("Q4 test:",q4_are_anagrams("hello", "world"))

    # Q5
    print("Q5 example:",q5_first_repeating("programming"))
    print("Q5 test:",q5_first_repeating("abcdef"))

    # Q6
    print("Q6 example:",q6_move_zeros([0,3,0,1,2,0,4]))
    print("Q6 test:",q6_move_zeros([1,0,2]))

    # Q7
    print("Q7 example:",q7_second_highest([10,20,40,30,40,20]))
    print("Q7 test:",q7_second_highest([5,5,2]))

    # Q8
    print("Q8 example:",q8_remove_duplicates([4,2,4,5,2,7,5]))
    print("Q8 test:",q8_remove_duplicates([1,1,2,3,2]))

    # Q9
    print("Q9 example:",q9_missing_number([1,2,4,5,6],6))
    print("Q9 test:",q9_missing_number([1,3,4],4))

    # Q10
    print("Q10 example:",q10_two_sum([2,7,11,15],9))
    print("Q10 test:",q10_two_sum([1,4,6,8],10))

    # Q11
    print("Q11 example:",q11_closest_to_zero([-8,-3,2,5,-2]))
    print("Q11 test:",q11_closest_to_zero([-4,1,-1,3]))

    # Q12
    print("Q12 example:",q12_common_elements([1,2,3,4,5],[3,4,5,6,7]))
    print("Q12 test:",q12_common_elements([4,2,4,1],[2,4,8]))

    # Q13
    print("Q13 example:",q13_rotate_right([1,2,3,4,5],2))
    print("Q13 test:",q13_rotate_right([10,20,30],1))

    # Q14
    print("Q14 example:",q14_max_consecutive_sum([4,7,2,9,5]))
    print("Q14 test:",q14_max_consecutive_sum([-2,-5,-1,-3]))

    # Q15
    print("Q15 example:",q15_all_pairs([2,4,3,5,7,8,1],9))
    print("Q15 test:",q15_all_pairs([1,2,3,4],20))

if __name__ == "__main__":
    main()
